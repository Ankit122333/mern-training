function Person(){
    this.age = 0

    setInterval(function(){
        this.age++;
        console.log(this.age)
    }.bind(this), 0.0000000000001) // bind sirf callback function m hi use krna hota hai.

}
const p1 = new Person()


//using arrow functions
function Person(){
    this.age = 0

    setInterval(()=>{
        this.age++
        console.log(this.age)
    },1000)
}
const p2 = new Person()


const team = {
    members: ['Alice', 'Bob', 'Charlie'],
    teamName: 'Developers',
  
    logMembers: function() {
      this.members.forEach(member => {
        console.log(`${member} is part of ${this.teamName}`);
      });
    }
  };
  
team.logMembers();
  