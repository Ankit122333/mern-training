//without Argumnts
let currentDate = new Date();
console.log(currentDate) // global time show hoga av yha p.. date to shi hi aayega

//with date and time string(using date string)
let specificDate = new Date('2025-04-09T12:08:16');
console.log(specificDate) // gmt+0000(UTC) m convert kr rha h ye

let dateWithParts = new Date(2025,3,9,12,39,0)
console.log(dateWithParts)
//note: months in js are 0-indexed (jan is 0; dec is 11)\

let dateFromMilliseconds = new Date(0) //1970-01-01T00:00:00.000Z
console.log(dateFromMilliseconds) // millisecond ka chije 1970 ko picture m aayi thi to iska op v usi date ka hi hoyega


//getting date information

let date1 = new Date()
console.log(date1.getFullYear())  //2025
console.log(date1.getMonth())  //3 (0-11; where jan is 0)
console.log(date1.getDate())  //9 (1-31)
console.log(date1.getDay())  //3 (0-6; where 0 is sunday)
console.log(date1.getHours())  //12 (0-23)
console.log(date1.getMinutes())  //20(0-59)
console.log(date1.getSeconds())  //39(0-59)
console.log(date1.getMilliseconds())  //298 (0-999)

let now = new Date(); //agar Date(0) likhoge to gmt+0000 wala time lega
console.log(`Today's date is: ${now.getFullYear()}-${now.getMonth()+1}-${now.getDate()} and 
Time is: ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`)


//we can set the date & time
let date3=new Date(); 
date3.setFullYear(2025)
date3.setMonth(11)
date3.setDate(25)
date3.setHours(14)
date3.setMinutes(30)
console.log(date3)

let date4 = new Date()
let date5 = date4.toLocaleString() //4/9/2025, 12:52:12 PM
let date6 = date4.toDateString() // Wed Apr 09 2025 
let date7 = date4.toLocaleDateString() // 4/9/2025
let date8 = date4.toLocaleTimeString() // 12:52:12 PM
console.log(date5)
console.log(date6)
console.log(date7)
console.log(date8)


let ms = Date.parse('2025-04-09T12:53:00') // parse date string to number
console.log(ms)

// date comparison
let date9 = new Date('2025-04-09')
let date10 = new Date('2025-04-09')


// adding days to a date

let dt1 = new Date()
dt1.setDate(dt1.getDate()+7)
console.log(dt1)

// subtract hrs from the date
let dt2 = new Date()
dt2.setHours(dt2.getHours()-5) // subtract 5 hrs
console.log(dt2)





