// math library
// Math.round(number)
// Math.floor(number)
// Math.ceil(number)

let n=4.7
console.log(Math.round(n))  //o/p - 5
console.log(Math.floor(n))  //o/p - 4
console.log(Math.ceil(n))  //o/p - 5

// finding max and min
// Math.max(): return the largest of 0 or more no.s
// Math.min(): return the smallest of 0 or more no.s

console.log(Math.max(10,30,55.5)) //55.5
console.log(Math.min(10,30,55.5)) //10
console.log(Math.max(-1.20%-1.01, 0.05%0.2, -0.23%0.1)) // 0.05

//square root & power
console.log(Math.sqrt(16))
console.log(Math.pow(2,3))

// random method - generates pseudo no. bw 0(inclusive) to 1(exclusive).
let ranno = Math.random()
console.log(ranno.toFixed(3))

let ranscaled = Math.random()*100
console.log(ranscaled)

//absolute value - -ve ko +ve m change krta h
console.log(Math.abs(-7))

// trigonometric functions

console.log(Math.sin(90))
console.log(Math.cos(90))

let angleInRadians = Math.PI/2 //90 degrees
console.log(typeof(angleInRadians))
console.log(Math.sin(angleInRadians)) //1
console.log(Math.cos(angleInRadians)) //1

let degrees = 90;
let radians = degrees * (Math.PI / 180);
// Cosine of 90 degrees in radians
let result = Math.cos(radians);
console.log(result); 


//log
console.log(Math.log(1)) //0
console.log(Math.log10(100)) // 2

//round
let num = 5.6789
let roundednum = Math.round(num*100)/100
console.log(roundednum)

//exponent and logs
// Math.exp(exponent) - return the value of e raised tro the power of the given expo
// Math.log(numer) - return the natural log (base e) of a number
console.log(Math.exp(1)) // 2.718281828459045


let isRainy = false;
let hasUmbrella = true;

if (isRainy || hasUmbrella) {
    console.log("You can go outside.");
}

// Logical Not
let isLoggedIn = false;

if (!isLoggedIn) {
    console.log("Please log in.");
}
// Output: Please log in.

let age = 18;
let canVote = (age >= 18) ? "Yes, you can vote." : "No, you cannot vote.";
console.log(canVote);

let haslicense = true;
let issober = true;
let candrive = (haslicense && issober) ? "You can drive." : "You cannot drive.";

console.log(candrive);




