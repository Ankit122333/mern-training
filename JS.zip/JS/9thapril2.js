//strings - initialization, concatenation, manipulation
//template literals - ``- backtick is used to write
// concatenation
//using + operator; using template literals
//length
// accessing the character
// changing case
// string & Substring & substr .substring() or .slice()
// replace substring   
let greet = "Hello " + "Bhai!!"
console.log(greet) 

let name1 = "Knock Knock!!"
let msg = `Welcome, ${name1}`

console.log(msg)
console.log(greet.concat(msg))
console.log(greet.concat(' ',msg))

console.log(name1.length) // O/p - 13
console.log(name1[3]) //c
console.log(greet[7]) //h

console.log(greet.toUpperCase()) // HELLO BHAI!!
console.log(msg.toLowerCase()) // welcome, knock knock!!

console.log(name1.substring(3,10)) // ck Knoc // negative indices not allowed 

console.log(name1.slice(3,10)) // ck Knoc
console.log(name1.slice(-6)) // nock!! piche side se 6 character print krega. name sttring ka 

// replaces
let text = "I love javascript!"
let newtext = text.replace("love", "enjoy")

console.log(newtext)

//split strings
let texxtt = "apple, banana, cheerry";
let fruits = texxtt.split(",")
console.log(fruits)

//indexOf
let str2 = "JavaScript is Awesome!!";
let index = str2.indexOf("Awesome")
console.log(index)

//includes
console.log(str2.includes("is")) //true

// startsWith() and endsWith()

console.log(str2.startsWith("Ja"))
console.log(str2.endsWith("!")) 

//repeat()

let str3 = "ha!"
let repeatedText = str3.repeat(3)
let repeatedText1 = str3*3 // will give output as NaN
console.log(repeatedText)
console.log(repeatedText1) // NaN as the oputpit






