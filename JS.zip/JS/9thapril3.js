// template literals for multiple strings
let poem = `roses are red,
violets are blue,
js is fun,
so are you.`
console.log(poem)

// trimming whitespace
let s1 = " Hello, World!. "
console.log(s1.trim())
console.log(s1.trimEnd())

//converting to and from strings
let num = 123
let strNum = num.toString();
console.log(strNum)

//other datatypes to string
let booleanValue = true
let stringBoolean = String(booleanValue)
console.log(stringBoolean) // true
console.log(typeof(stringBoolean)) // string

//string manipulation in action
let fname = "ankit"
let lname = "kumar"
let fullname = fname + " " + lname
let extractedfname = fullname.slice(0,fullname.indexOf(" "))
console.log(extractedfname) // ankit

// analyzing and modifying the string in js
// modification- concat, slicing, replacing, substring, slice, lowercase, uppercase, trim, split
// length - property, not a method
// charAt(index) - 