const stringUtils = require('./stringUtils')
const arrayUtils = require('./arrayUtils')
const greet = require('./greet')
const user = require('./getUsers')
const authenticate = require('./auth')

//using stringUtils function
const str1 = "Hello, Dunia, Ankit this side"
console.log(stringUtils.toUpperCase(str1))
console.log(stringUtils.contains(str1, 'kaise'))

//using arrayUtils function
const nums = [1,2,2,2,3,3,4,4,4,5,5]
console.log(arrayUtils.findMax(nums))
console.log(arrayUtils.removeDupli(nums))

//using greet function
const name = "Nanda"
console.log(greet.sayHello(name))
console.log(greet.sayBye(name))

//using auth & getUser function 
// add users

user.addUser('Alice')
user.addUser('Bob')

const allusers = user.getUsers();
console.log("uers: ", allusers)


const isAuthenticated = authenticate.authenticateUser("Knock Knock")
console.log('is Knock Knock authenticated?', isAuthenticated)

const moment = require('moment')

const formattedDate = moment().format('MMMM DD YYYY, h:mm:ss a')
console.log('Current Date: ',formattedDate)

console.log(__dirname)
console.log(__filename)
console.log("Hello bhaii")
console.warn("warning!!")
console.error("this is error")
console.log("Node js version:",process.version)
console.log("Node js version:",process.platform)
console.log("command-line-arguments: ", process.argv)
console.log("Available Memory ", process.availableMemory())

process.on('exit', (code)=>{
    console.log(`Exiting with code: ${code}`)
})




