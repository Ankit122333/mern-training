// app1.js
const counter = require('./counter');

console.log(counter.increment()); // Output: 1
console.log(counter.increment()); // Output: 2

//const counter = require('./counter');

console.log(counter.getCount()); // Output: 2 (reflects the state from app1.js)