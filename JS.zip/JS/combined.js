//define a function
function sayHi(){
    return 'Hi!'
}

// add to exports
exports.sayHi = sayHi;

//ovverride module.exports with an object
module.exports = {
    message:"Welcome!",
    status: "Active"
}

