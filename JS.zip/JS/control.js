let a= -0.005/0.01
let b= -0.005/0.01
if(a>b){
    console.log("A is greater than b")
}
else{
    console.log("A is less than b")
}
 
let day=1
switch(day){
    case 1: console.log('monday'); break;
    case 2: console.log('tuesday'); break;
    case 3: console.log('invalid day'); break;
} 


for(var i=0; i<5;i++){
    console.log(i)
}

let ab = 10;
while(ab<10){
    ab++;
}
console.log(ab)


let add = (a,b) => a+b; // arrow function
console.log(add(5,3))

let square = function(x){ // function expression
    return x*x;
}
console.log(square(4))

function greet(name){ // funciton declaration
}
console.log(greet('Ankit'))


let person = {
    name: "Ankit",
    age: 22,
    age:45,
    greet:function(){
        return "Hello, "  + this.name
    }
}
console.log(person.greet())
console.log(person.age)
console.log(person)
console.log(person['age'])


let fruits=['apple', 'banana', 'cherry']
console.log(fruits[1])

console.log(fruits.push("orange")) // adds at last
console.log(fruits.pop()) // removes the last element of the array
console.log(fruits.shift()) // removes the 1st element of the array
console.log(fruits.unshift("mango"))
//console.log(fruits.foreach(fruits.map()))

fruits.forEach(function(fruit,index){
    console.log(`Fruit at index ${index} is ${fruit}`)
})

function person(fname, lname, age){
    this.fname = fname
    this.lname = lname
    this.age = age
}
const person1 = new Person('jane','Doe', 25)
console.log(person1.fname)


    