//db.js
class Database {
    constructor() {
        if (!Database.instance) {
            this.connection = this.connect()
            Database.instance = this;
        }
        return Database.instance
    }

    connect() {
        console.log('connecting to the database...')
        return {} //simulate a datbase connection
    }
}

const instance = new Database()
Object.freeze(instance) // optional
module.exports = instance

