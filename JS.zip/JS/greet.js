exports.sayHello = function(name){
    return `Hello, ${name}!`
}
exports.sayBye = function(name){
    return `GoodBye, ${name}`
}