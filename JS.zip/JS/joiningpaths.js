const path = require('path')

//joining paths
const filePath = path.join(__dirname,'files','example.txt')
console.log("file path: ",filePath)

//console file name
const fileName = path.basename(filePath)
console.log("File name: ",fileName)

//getting extension
const ext = path.extname(fileName)
console.log("Extension: ", ext)