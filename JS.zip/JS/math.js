export function add(a,b){
    return a+b
}
export const PI = 3.14