//block-1
let person = {
    name1:"Ankit",
    age: 22,

    // method to return the greet message
    greet : function(){
        return `Hello, My name is ${this.name1}.`
    },

    // method to calculate the year of birth

    getYearofBirth: function(){
        let curryr = new Date().getFullYear()
        return curryr-this.age
    }
}
console.log(person.greet()) // hello, my name is ankit
console.log(person.getYearofBirth()) // return year of birth

//block-2
let person1 = {
    name2:"Ankit",
    age1: 22,

    // method to return the greet message
    greet(){ // in ES-6 onwards, no need to define the function keyword.
        return `Hello, My name is ${this.name2}.`
    },

    // method to calculate the year of birth
    getYearofBirth(){ //// in ES-6 onwards, no need to define the function keyword.
        let curryr1 = new Date().getFullYear()
        return curryr1-this.age1
    }
}
console.log(person.greet()) // hello, my name is ankit
console.log(person.getYearofBirth()) // return year of birth

//block-3
//this keyword game
let car = {
    brand:"Toyota",
    model:"Camry",
    year:2020,

    describe(){
        return `This is a ${this.year} model ${this.brand} - ${this.model} car.`
    }
}
console.log(car.describe()) // This is a 2020 model Toyota - Camry car.


//block-4
let book = {
    title:"1984",
    author:"George"
}
//adding a method after the object is created
book.getSummary = function(){ // agar object scope k andar hi method bana rhe ho to koi issue nahi..
    return `${this.title} by ${this.author}`
}
console.log(book.getSummary()) //1984 by George

//block-5
//arrow functions and this keywords
let user = {
    name3:"Ankit",
    greet1:()=>{
        return `Hello, my name is ${this.name3}.`
    }
}
console.log(user.greet1()) // 'this' does not refer to the user object\

//block-6
let bankAccount = {
    accountHolder: "Jane Doe",
    balance: 5000,
    
    deposit(amount) {
      this.balance += amount;
      return `New balance is ${this.balance}.`;
    },
    
    withdraw(amount) {
      if (amount > this.balance) {
        return `Insufficient funds.`;
      }
      this.balance -= amount;
      return `New balance is ${this.balance}.`;
    }
  };
  
  console.log(bankAccount.deposit(1000)); // New balance is 6000.
  console.log(bankAccount.withdraw(7000)); // Insufficient funds.
  console.log(bankAccount.withdraw(3000)); // New balance is 3000.

// block-7
// freezing objects
"use strict"
const car1 = {
    brand1:"Audi",
    model1:"Q7",
    address:{city:"Pune", country:"India"}
}
Object.freeze(car1)
Object.freeze(car1.address) // to freeze the address property ; shallo9w freeze bolte h iseko
car1.model1 = "Q3" // attempting to change the property but this will fail
car1.year = 2023
car1.address.city = "Mumbai" // attempting to add the new property and it will be updated.

console.log(car1) // references are not frozen. only objects are frozen

//block-8 - Shallow Freeze
const books={
    title:"JS Guide",
    author:{name4:"JohnDoe", age:40}
}
Object.freeze(books)
books.author.age =45 // this works bcoz freeze is shalloe
console.log(books.author.age) // o/p - 45

//block - 9
//DeepFreeze
function deepFreeze(obj) {
    // First freeze the object itself
    Object.freeze(obj);
  
    // Now freeze all properties that are objects
    Object.keys(obj).forEach(key => {
      if (typeof obj[key] === 'object' && obj[key] !== null) {
        deepFreeze(obj[key]);
      }
    });
  }
  const user1 = {
    name: "Ankit",
    details: {
      age: 22,JobRole : "ASE",
      address: {
        city: "Pune",
        country: "India"
      }
    }
  };
  deepFreeze(user1);
  user1.details.age = 30;
  user1.details.address.city = "Hyderabad"  // This will now fail as well
  
  console.log(user1);
  console.log(user1.details.age);
  console.log(user1.details.address.city)  // Output: 22
