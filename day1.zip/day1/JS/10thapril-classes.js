//using classes to build js object
//classes, constructors, objects & Examples

// Class: A blueprint for creating objects with specific properties and methods.
// Constructor: A special method inside a class that initializes object properties.
// Methods: Functions defined inside a class that perform actions related to the object.

// Example of Creating and Using Classes

// 1. Defining a Class
class Person {
  // Constructor method to initialize properties
  constructor(name, age, gender) {
    this.name = name;
    this.age = age;
    this.gender = gender;
  }
  // Method to introduce the person
  introduce() {
    return `Hi, my name is ${this.name}. I am ${this.age} years old.`;
  }
  // Method to display the gender of the person
  showGender() {
    return `${this.name} is ${this.gender}.`;
  }
}
// Creating an object using the Person class
const person1 = new Person('Alice', 30, 'female');
// Using methods of the Person class
console.log(person1.introduce()); // Output: Hi, my name is Alice. I am 30 years old.
console.log(person1.showGender()); // Output: Alice is female.


class Student extends Person {
    constructor(name, age, gender, course) {
      // Call the parent class constructor to initialize the inherited properties
      super(name, age, gender);
      this.course = course;
    }
    // Method to display the student's course
    showCourse() {
      return `${this.name} is studying ${this.course}.`;
    }
  }
  // Creating an object using the Student class
  const student1 = new Student('Bob', 22, 'male', 'Computer Science');
  // Using methods from both Student and Person classes
  console.log(student1.introduce()); // Output: Hi, my name is Bob. I am 22 years old.
  console.log(student1.showCourse()); // Output: Bob is studying Computer Science.


// ES - 6 Features
// variables & Datatypes
// primitive & non primitive
// primitive -  Number, String, Boolean, undefined, Null, Symbol, BigInt
// non primitive - objects & arrays

//Destructuring - ES6
//2 types - array and object destructuring
//array - destructuring
const nums1 = [1,2,3]
let [a,b,c] = nums1
console.log(a,b,c)
console.log(a+c)

//object - destructuring
const person2 = {fname:"ankit", age:22}
let {fname,age} = person2
console.log(fname,age)
console.log(person2)

//Promises(ES6)
//Modules - export, import
//main.js & app.js

//async - await ( ES 2017)

const fetchData = () =>{
    return new Promise((resolve,reject)=>{
        setTimeout(()=>resolve("Data Fetched"),2000)
    })
}

async function fetchAsyncData() {
    const data = await fetchData()
    console.log(data)  // data fetched after 2sec
}
fetchAsyncData()

//template string, literals// multi line strings
//\n
multi = "hello\n" + "Ankit!!"
console.log(multi)

// expression interpolation
//Template literals allow embedding expressions directly inside the string using the ${} syntax. You can embed any valid JavaScript expression inside it, including arithmetic operations and function calls.


let x = 10;
let y = 20;
let result = `The sum of ${x} and ${y} is ${x + y}.`;
console.log(result);  // Output: The sum of 10 and 20 is 30.

//Example with function interpolation:

// function getGreeting(name) {
//   return `Hello, ${name}!`;
// }

// let greetingMessage = `${getGreeting('Alice')}`;
// console.log(greetingMessage);  // Output: Hello, Alice!

// // Tagged TEmplate Literals
// function tag(strings, ...values) {
//     console.log(strings);  // Array of string parts
//     console.log(values);   // Array of interpolated values
//     return 'Processed Template';
//   }
  
//   let result1 = tag`Hello, ${name1}. You are ${age} years old.`;
//   console.log(result1);  // Output: Processed Template.


//class expressions - can also be defined using expressions
  
const Animal1 = class{
    constructor(species,sound){
        this.species = species
        this.sound = sound
    }
    makeSound(){
        console.log(`${this.species} makes a ${this.sound} sound.`)
    }
}

const dog = new Animal1("Dog", "Bhaw Bhaw")
const cat = new Animal1("Cat", "Meow Meow")
dog.makeSound()
cat.makeSound()

// Getters & Setters

class Rect {
    constructor(width,height){
        this.width = width
        this.height = height
    }
    get Area(){
        return this.width * this.height
    }
    set dimensions({width,height}){
        this.width = width
        this.height = height
    }
}

const Rect1 = new Rect(10,20)
console.log(Rect1.Area) // 200

Rect1.dimensions = {width:15, height:25}
console.log(Rect1.Area) // 375

//static methods - belongs to the class itself rather than the instances of the classes.

class MathUtils{
    static sq(num){
        return num*num
    }
}

console.log(MathUtils.sq(5)) //25

//spread operator (...)
const org = [1,2,3]
//const copy1 = org
const copy2 = [...org]
copy2.push(4)

console.log(org)
//console.log(copy1)
console.log(copy2)
// const original = [1, 2, 3];
// const copy = [...original];
// copy.push(4);
// console.log(original); // Output: [1, 2, 3]
// console.log(copy);     // Output: [1, 2, 3, 4]

//merging arrays

const arr1 = [1,2,3]
const arr2 = [4,5,6]
const merged = [...arr1, ...arr2]
console.log(merged)  // [ 1, 2, 3, 4, 5, 6 ]

//spreading elements of a string - spread operator can break a string into individual character

const str = "Hello"
const chars = [...str]
console.log(chars) //[ 'H', 'e', 'l', 'l', 'o' ]

//Using with function argument - spread operators can be used to pass elements of an array as arguments to a function
function add(a,b,c,d){
    return a+b+c+d
}
const numss = [1,2,3,4] // arguments
console.log(add(...numss))
//if no. of parameter is more=> NaN will be the op


//spreading object properties -  can be used to copy or merge objects as well.

const obj1 = {a: 1, b: 2}
const obj2 = {c: 3, d: 4}
const combined = {...obj1, ...obj2}
console.log(combined) // o/p - { a: 1, b: 2, c: 3, d: 4 }

//shallow coyping objects - similar to arrays u can make a shallow copy of an object
const pers = {name1 : "Ankit", age : 22}
// const clone = pers
// console.log(clone)
const clone1 = {...pers}
clone1.age = 24
console.log(pers.age) //22
console.log(clone1.age) //24

const ob1 = {a:1, b:{c:2}}
const ob2 = ob1 //{...ob1}
ob2.b.c=3
console.log(ob1.b.c)
console.log(ob1)
console.log(ob2)

//Rest Parameters : while they look similar (...) the rest parameters gather remaining element into array,
//whereas the spread operator expands elements

function sum1(...numbber){
    return numbber.reduce((total,numm) =>total + numm)
}
console.log(sum1(1,2,3,4.5))


//
