let name1 = "John"
let html = `
    <div>
        <h1>Hello, ${name1}</h1>
        <p>This is a paragraph</p>
    </div>`
console.log(html)

