//map method for js arrays
// Block - 1 : basic  example
const nums = [1,2,3,4,5]
const doubled = nums.map(function(nums){
    return nums*2;
})
console.log(`Given array is: ${nums} and
Doubled array is: ${[doubled]}`)
console.log(doubled)
// it will implement the line 5 in each element of the array.

//Block - 2 : array of objects
const ppl = [
    {name:"John", age:20},
    {name:"Jane",age:21},
    {name:"Jack",age:22}

]
const names = ppl.map(function(person){
    return person.name
})
const ages = ppl.map(function(person){
    return person.age
})
console.log(names) //[ 'John', 'Jane', 'Jack' ]
console.log(ages) //[ 20, 21, 22 ]

// Block - 3 : using arrow functions with map
const nums1 = [1,2,3,4,5]
const sqd = nums1.map(num=>num*num)
console.log(sqd)


//Block - 3 : index parameter
const nums2 = [10,30,20]
const res = nums2.map((num,index)=>{
    return `Element at index ${index} is ${num}`
})
 console.log(res) // o/p is: [
//     'Element at index 0 is 10',
//     'Element at index 1 is 30',
//     'Element at index 2 is 20'
// ]
// immutable - does not change the original array
// callback function - u must provide the call back function
// non mutating - it does not afftect the original array


//Block - 4 : reduce and filter methods in js arrays
//SYNTAX -  array.reduce(callback,initialValue)
// reduce - to get the single result from the array
// filter - to get some part of the array; condition will be applied
const nums3 = [10,20,30,40,50] // SUM OF ALL NO.S
const summ=nums3.reduce((accumulator,currentValue)=>{
    return accumulator + currentValue;
},0)
console.log(summ)
console.log(typeof(summ))

//flatten an array of arrays
const arrofarr = [[1,2],[3,4],[5]]
const flattend = arrofarr.reduce((acc,curr)=>{
    return acc.concat(curr);
},[])
console.log(flattend)

// Block - 5 : filter() method
// filter method is used to create a new array 
//with all elements that pass  the implemented by the provided funciton
//SYNTAX - array.filter(callback)

const nums4 = [1,2,3,4,5,5,6,7,8,8]
const evens = nums4.filter(num=>{
    return num%2===0
})
console.log(evens) //[ 2, 4, 6, 8, 8 ]
//Example-2
const people = [
    { name: 'John', age: 25 },
    { name: 'Jane', age: 20 },
    { name: 'Jack', age: 30 }
  ];
  
  const adults = people.filter((person) => {
    return person.age >= 21;
  });
  
  console.log(adults);


// Task :  to filter out the name starting with 'J'
const namess = ["John","Alice","Jack","Bob",'Jackob']
const res1 = namess.filter((name1)=>{
    return name1.startsWith("J") // O/P - [ 'John', 'Jack' ]
})
console.log(res1)

//Block - 6 : instanceOf Operator
//syntax = instanceof constructor; All the object is the object of 'Object' class

class Animal{}
class Dog extends Animal{}
let myDog = new Dog();
console.log(myDog instanceof Dog);  // true
console.log(myDog instanceof Animal);  // true
console.log(myDog instanceof Object);  // true
console.log(myDog instanceof String);  // false

//Example-2 - using with built-in types

let arr4 = [1,2,34,4]
console.log(arr4 instanceof Array)  // true
console.log(arr4 instanceof Object)  // true
console.log(arr4 instanceof String)  // false
console.log(arr4 instanceof Number)  // false

console.log(typeof(arr4))  //object

//Example-3 : custom constructor function

function car2(make,model){
    this.make = make;
    this.model = model;
}
let mycar = new car2("Audi", "Q3")
console.log(mycar instanceof car2)  //true
console.log(mycar instanceof Object)  //true
console.log(typeof(mycar))  //object

//Example - 4 :  Edge Classes
// primitives
console.log("hello" instanceof String) // false
console.log(123 instanceof Number) // false

// Null & Undefined
console.log(null instanceof Object) // false
console.log(undefined instanceof Object) // false

//Block - 6: Modifying prototypes; instance of relies on the object's prototypes chain
class Person1{
}
let individual = new Person1()

//Before modifying prototype
console.log(individual instanceof Person1)  // true

Person1.prototype = {}
let individual1 = new Person1()
console.log(individual1 instanceof Person1) // true









