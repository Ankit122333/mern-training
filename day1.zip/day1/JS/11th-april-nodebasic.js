const http = require('http');

http.createServer((req,response) =>{
    response.writeHead(200,{"content-type": "text/plain"})
        response.end("Hello Dunia\nI am new to Node.js")  
}).listen(3000,()=>{
    console.log("Server running at port 3000")
})

//http - predefined module

console.log("🟢 start"); // ✅ Synchronous

setTimeout(() => {       // 🔄 Asynchronous (goes to Timers Phase) macrotasks
  console.log("⏱ setTimeout 3s");
}, 2000);

setImmediate(() => {     // 🔄 Asynchronous (goes to Check Phase)
  console.log("🚀 setImmediate");
});

Promise.resolve().then(() => { // 🔄 Asynchronous (goes to Microtask Queue)
  console.log("✅ Promise then");
});

process.nextTick(() => {       // 🔄 Asynchronous (Microtask, runs before promises)
  console.log("⚡ process.nextTick");
});

console.log("🔴 end");   // ✅ Synchronous

// 🧠 Breakdown of Output Order:
// Line in Output	Why It Runs When It Does
// 🟢 Start	Top-level sync code
// 🔴 End	Top-level sync code
// ⚡ process.nextTick	Always runs after sync
// ✅ Promise then	Runs in Microtask Queue
// 🚀 setImmediate	Runs in Check Phase
// ⏱ setTimeout	Runs in Timers Phase

console.log("🟢 start"); // ✅ Synchronous

setTimeout(() => {       // 🔄 Asynchronous (goes to Timers Phase) macrotasks
  console.log("⏱ setTimeout 1s");
}, 2000);

setTimeout(() => {       // 🔄 Asynchronous (goes to Timers Phase) macrotasks
  console.log("⏱ setTimeout 0.5s");
}, 500);

Promise.resolve().then(() => { // 🔄 Asynchronous (goes to Microtask Queue)
  console.log("✅ Promise 1");
});

Promise.resolve().then(() => { // 🔄 Asynchronous (goes to Microtask Queue)
  console.log("✅ Promise 2");
});


console.log("🔴 end"); 


console.log("🔴 start"); 
setTimeout(() => {       // 🔄 Asynchronous (goes to Timers Phase) macrotasks
  console.log("⏱Timeout 1");

  Promise.resolve().then(() => { // 🔄 Asynchronous (goes to Microtask Queue)
    console.log("✅ Promise 1");
  });
},);
console.log("🔴 end"); 