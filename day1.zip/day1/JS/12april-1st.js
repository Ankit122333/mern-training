const os = require ('os') // line9
const EventEmitter = require('events') //line 25
//const Stream = require('stream')
const buffer = Buffer.from("Hello") // create  buffer from a string; buffer module
const crypto = require('crypto') // line 44
const {URL} = require('url') // url module which provides utilities for URL resolution & parsing
const url = require('url')
const zlib = require('zlib')
const fs = require('fs')


// //get information about the system
// console.log('Operating sysyem: ',os.type())
// console.log('Total Memory: ',os.totalmem())
// console.log('Free Memory: ',os.freemem())
// console.log('CPU Info: ',os.cpus())
// console.log(os.platform())
// console.log(os.hostname())
// console.log(os.machine())
// console.log(os.version())
// console.log(os.homedir())
// console.log(os.networkInterfaces())
// console.log(os.arch())
// console.log(os.loadavg())



// const emitter = new EventEmitter() //creatingan event emitter instances 
// //defining an event listener
// emitter.on('greet',(name1) =>{
//     console.log(`Hello, ${name1}`)
// })
// //emitting the event
// emitter.emit('greet','Ankit!')

// //convert the buffer to string
// console.log(buffer.toString()) // Hello


// //create an empty buffer of size 10
// const emptyBuffer = Buffer.alloc(10)
// console.log(emptyBuffer) // op a buffer of size 10 zero filled bytes
// //buffers are useful when dealing with raw binary data such as files or streams
// // buffer--------->> Streams 
// // 1.)Readable     2.)writable     3.)duplex   4.)Transform

// //Example: Hashing Data
// //create a SHA256 hash of a string
// const hash = crypto.createHash('SHA256').update('Hello, World!').digest('hex')
// console.log(hash)

// //random token generation -- callback funtions
// crypto.randomBytes(16,(err,buffer)=>{
//     if(err) throw err
//     console.log("Random Token: ", buffer.toString('hex'))
// })

// //Public & Private Key Generation
// const{publicKey, privateKey} = crypto.generateKeyPairSync('rsa',{
//     modulusLength:2048
// })
// console.log("Public Key: ",publicKey.export({type:'pkcs1', format:'pem'}))
// console.log("Private Key: ",privateKey.export({type:'pkcs1', format:'pem'}))

// //for encryption & decryption
// function encryptData(data){
// return crypto.publicEncrypt(publicKey,Buffer.from(data)).toString('base64')
// }

// function decryptData(encryptData){
//     return crypto.privateDecrypt(privateKey,Buffer.from(encryptData, 'base64')).toString()
//     }

// const message = "Confidential Data."
// const encryptMessage = encryptData(message)
// console.log('Encrypted:',encryptMessage)
// const decryptMessage = decryptData(encryptMessage)
// console.log('Decrypted:',decryptMessage)

// //another example
// const password = 'securepassword'
// const salt = crypto.randomBytes(16).toString('hex')
// crypto.pbkdf2(password,salt,100000,64,'sha512',(err,derivedKey)=>{
//     if(err) throw err
//     console.log("derived Key: ",derivedKey.toString('hex'))
// })


//URL wla ka part
// const myurl = new URL('https://www.example.com:8080/path?name=nodejs#hash')

// console.log(myurl.href)   // O/p - https://www.example.com:8080/path?name=nodejs#hash
// console.log(myurl.protocol)   // O/p - https:
// console.log(myurl.host)   // O/p - www.example.com:8080
// console.log(myurl.hostname)   // O/p - www.example.com
// console.log(myurl.port)   // O/p - 8080
// console.log(myurl.pathname)   // O/p - /path
// console.log(myurl.search)   // O/p - ?name=nodejs
// console.log(myurl.hash)   // O/p - #hash
// console.log(myurl.origin)    // O/p - https://www.example.com:8080


// //formatting the url
// myurl.pathname = '/api/user'
// myurl.searchParams.append('id',123)
// myurl.searchParams.append('status','active')
// console.log(myurl.toString()) //https://www.example.com:8080/api/user?name=nodejs&id=123&status=active#hash


// //working with the  query parameter
// const myurl1 = new URL('https://example.com?name=John&age=30')
// console.log(myurl1.searchParams.get('name')) //John
// console.log(myurl1.searchParams.get('age')) //30
// myurl1.searchParams.append('city','New York') 
// console.log(myurl1.toString()) // //https://example.com/?name=John&age=30&city=New+York
// myurl1.searchParams.delete("age")
// console.log(myurl1.toString())  // https://example.com/?name=John&city=New+York

// //another example
// const myurl2 = new URL('https://www.google.com/search?q=node+js&sca_esv=25cf531ee370dd12&source=hp&ei=QofOZ6G4EPrt1e8PqKmW0As&iflsig=ACkRmUkAAAAAZ86VUgW41_L5xuf-3Bn3RoJ2cGQLFd0k&ved=0ahUKEwih4Yv78f6LAxX6dvUHHaiUBboQ4dUDCBo&uact=5&oq=node+js&gs_lp=Egdnd3Mtd2l6Igdub2RlIGpzMggQABiABBixAzIIEAAYgAQYsQMyCBAAGIAEGLEDMggQABiABBixAzIFEAAYgAQyCBAAGIAEGLEDMgUQABiABDIIEAAYgAQYsQMyBRAAGIAEMgUQABiABEj0JFAAWPYgcAJ4AJABAJgB3QGgAeEMqgEFMC43LjK4AQPIAQD4AQGYAgugAqQNwgIOEAAYgAQYsQMYgwEYigXCAhEQLhiABBixAxjRAxiDARjHAcICDhAuGIAEGLEDGIMBGIoFwgILEAAYgAQYsQMYgwHCAg4QLhiABBixAxjRAxjHAcICCxAuGIAEGLEDGOUEwgILEC4YgAQYsQMY1ALCAggQLhiABBixA8ICCxAAGIAEGLEDGIoFmAMAkgcFMi43LjKgB9JA&sclient=gws-wiz')
// console.log(myurl2.searchParams.get('q'))  //node js 
// console.log(myurl2.searchParams.get('sca_esv'))  // 25cf531ee370dd12

// //resolving the url
// const baseUrl = 'https://example.com/home/'
// const relativePath = '../about'

// const resolvedUrl = url.resolve(baseUrl,relativePath)
// console.log(resolvedUrl) //https://example.com/about
// //another way to resolve the url
// const resolvedUrl1 = new URL('../about','https://example.com/home.')
// console.log(resolvedUrl1.href) //https://example.com/about

// //encoding & decoding
// const queryString = "Hello Ankit kaise ho mere bhai?"
// const encoded = encodeURIComponent(queryString)
// console.log(encoded) //Hello%20Ankit
// const decoded = encodeURIComponent(encoded)
// console.log(decoded) //Hello%2520Ankit

//zlib used to compress& decompress functionalities
//Compress a file
// const input = fs.createReadStream('input.txt')
// const output = fs.createWriteStream('input.txt.gz')
// input.pipe(zlib.createGzip()).pipe(output);

// Decompress a file
const gunzip = zlib.createGunzip();
const inputGz = fs.createReadStream('input.txt.gz');
const outputTxt = fs.createWriteStream('decompressed.txt');
inputGz.pipe(gunzip).pipe(outputTxt);



//override
//define