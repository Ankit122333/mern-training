//using the module
//import the module
const combined = require('./combined')

//access properties
console.log(combined.message)
console.log(combined.status)
console.log(combined.sayHi())// will give error

