let arr = new Array(1,2,3,4,5054,"abc")
console.log(arr)
// Example of creating an array

let fruits = ["Apple", "Banana", "Mango"]
console.log(fruits);  // Output: ["Apple", "Banana", "Mango"]

console.log(typeof(arr[5]))
console.log(typeof(arr[4]))

//Empty Array - Example
let emptyArray = [];
// Adding elements later
emptyArray[0] = "First";
emptyArray[1] = "Second";
console.log(emptyArray);  // Output: ["First", "Second"]

// Adding elements later
emptyArray[0] = "First";
emptyArray[1] = "Second";
console.log(emptyArray);  // Output: ["First", "Second"]
let cars = ["Tesla", "BMW", "Audi"];
console.log(cars[0]);  // Output: "Tesla"
console.log(cars[2]);  // Output: "Audi"

//concatenation
let arr1 = [1, 2, 3];
let arr2 = [4, "Ram", true];
let mergedArray = arr1.concat(arr2);
console.log(mergedArray);  // Output: [1, 2, 3, 4, 5, 6]
console.log(typeof(arr2[4]))
console.log(typeof(arr2[1]))
console.log(typeof(arr2[2]))

// for-each method
let n = [10,20,30]
n.forEach(function(n){
    console.log(n)
})

//for-of method
let cars1 = ["Tesla", "BMW", "Audi"];
for (let car of cars1){
    console.log(car)
}

// splicing and slicing arrays
let fruits1 = ['apples','banana','oranges','mangoes']
console.log(fruits1.slice(1,3))
// splice modify the original array

let col = ['red','green','blue','yellow','violet']
let remcol = col.splice(2,2)
console.log(remcol)
console.log(col)

let animals = ['dog','lion','elephant']
animals.splice(1,0,'elephant','lion')
console.log(animals) // 
let x = animals.splice(1,0,'elephant','lion')

//sorting function using array
let arr3 = [40,100,1,5,25,10]
console.log(arr3.sort()) // sort the array lexicographically.

arr3.sort(function(a,b){ // for descending order
    return b-a;
})
console.log(arr3)
arr3.sort(function(a,b){ // for ascending order
    return a-b;
})
console.log(arr3)

//concatenation + sorting
let array4 = [30, 5, 20];
let array5 = [15, 10, 25];
let concatenatedArray = array4.concat(array5);
// Sorting in ascending order
concatenatedArray.sort(function(a, b) {
  return a - b;
});
console.log(concatenatedArray); // Output: [5, 10, 15, 20, 25, 30]

//creating new objects from objects one

