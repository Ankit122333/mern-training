//creating new objects from objects one
//1.) 1st method
let car = {
    brand:"Toyota",
    model:"Camry",
    year:2020
}
let newCar = {
    brand: car.brand, // copying properties from the existing
    model:car.model,
    year:2021
}
console.log(car)
console.log(newCar)

//2.) Using create method - Object.create()

let person = {
    greet:function(){
        console.log(`Hello, My name is ${this.name1}, How's the day going?`)
    }
}
let john = Object.create(person)
john.name1 = "John"
john.greet()

//3.) Using the shallow copy - Object.assign()

let original = {
    name2:"Alice",
    age:24,
    address : {city:"Pune",country:"India"}
}

let copy = Object.assign({},original) // shallow copy
copy.age = 30 // modifies the new objects age property
copy.address.city = "Mumbai" // modifies the original objects city because it is a shallow copy

console.log(original)
console.log(copy)

// let original1 = {
//     name2:"Alice",
//     age:{agee:24},
//     address : {city:"Pune",country:"India"}
// }

// let copy1 = Object.assign({},original1) // shallow copy
// copy1.age = {agee:30} // modifies the new objects age property
// copy1.address.city = "Mumbai" // modifies the original objects city because it is a shallow copy

// console.log(original1)
// console.log(copy1)

let originalObject = {
    name: "Alice",
    age: 25,
    address: { city: "New York" }
  };

let deepCopy = JSON.parse(JSON.stringify(originalObject))
deepCopy.address.city = "Mumbai"
console.log(originalObject)

//5.) copying with the spread operator

let originalcar = {
    brand:"Honda",
    model:"Civic",
    specs:{color:"Burgundi", engine:"V6"}
}

let newcar = {...originalcar} // shallow copy
newcar.model = "Accord"
newcar.specs.color = "yellow" // this will change the color in both objects
console.log(originalcar)
console.log(newcar)