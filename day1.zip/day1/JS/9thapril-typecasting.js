//implicit typecasting - - happens automatically due to type coercion num+str = str
//explicit typecasting - 
let i = 0
while(i<3){
    console.log("iteration number: "+i)
    i++ - --i + ++i
    console.log(i)
}

console.log(10/0)
//Example 1: Basic try...catch Block

try {
    let result = 10 / 0;  // Dividing by zero, though in JavaScript this doesn't throw an error
    console.log(result);
    
    let a = undefinedVar;  // This will throw a ReferenceError
} catch (error) {
    console.log('An error occurred:', error.message); // Handling the error
}

function checkAge(age){
    if(age<18){
        throw new Error("Hey person!, You must be 18 or older..")
    } else{
        console.log("Hello Person, You are old Enough")
    }
}
try{
    checkAge(23);
} catch(error){
    console.log('Error:',error.message)
}

function fetchdata()
{
    return new Promise((resolve,reject) => {
        let success=true //simulating a failed api call
        if(success){
            resolve("Data fetched Successfully!!")
        } else{
            reject("Failed to fetch the data.")
        }

    })
}

fetchdata()
    .then(response => console.log(response))
    .catch(error => console.log('Error:', error));  // Handling the error in a Promise


//ASYNCHRONOUS ERROR HANDLING WITH async/await
async function getdata() {
    try {
        let result = await fetchdata();  // Assuming fetchData is an asynchronous function
        console.log(result);
    } catch (error) {
        console.log('Error:', error);  // Catching errors in async functions
    }
}

getdata();


