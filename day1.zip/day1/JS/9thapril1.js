// function myFunction(){
//     console.log(this)
// }
// myFunction()

// function myFunction1(){
//     "use strict"
//     console.log(this)
// }

// myFunction1()

// function sum(a,a,c){
//     return a+a+c
// }
// console.log(sum(10,10,20))


// // function sum(a,a,c){
// //     "use strict" // error will come as same variable cannt be reassigned
// //     return a+a+c
// // }
// // console.log(sum(10,10,20))

// "use strict"
// const obj={};
// Object.defineProperty(obj,"prop",{value:42,writable:false})
// obj.prop = 17;
// console.log(obj)
// //p : TypeError: Cannot assign to read only property 'prop' of object '#<Object>'

// "use strict"
// var x = 10
// delete x; //Delete of an unqualified identifier in strict mode.
// console.log(x)


// if(true){
//     var y=10;
// }
// console.log(y)

// if(true){
//     let y=10; // difference bw let and var :
//     console.log(y)
// }
// // console.log(y)

// let car = null 
// let car1 = {};
// console.log(car,car1)

// console.log(undefined===null)
//strict equality - ===; they are not equal bcoz they are of different types
// alert, prompt, confirm - isage dcenario og 
// loose equality - ==; 

//numbers in javascript
//  combination of integers and j
    //number type:
"use strict"
let num = 5.6789;
console.log(num.toFixed(2)); //toFixed ka uses h ye..
console.log(num.toString()); //toString
console.log(num.toPrecision(3)) //toPrecision - format a no. to a significant length

let num1 =43;
let num3 = toString(num1)
console.log(typeof(num3))

//parsing a no. to string
let str1 = "123"
console.log(parseInt(str1))
console.log(parseFloat(str1))

// number constant
// Number.MAX_VALUE
// Number.MIN_VALUE
// Number.POSITIVE_INFINITY
// Number.NEGATIVE_INFINITY
// Number.NaN
console.log(Number.MAX_VALUE)
console.log(Number.MIN_VALUE)
console.log(Number.POSITIVE_INFINITY)
console.log(Number.NEGATIVE_INFINITY)
console.log(Number.NaN)

let num4 = Number.MAX_VALUE
let expandedNum = num4.toFixed(0); // Convert to string with no decimal points

console.log(expandedNum);


console.log(isNaN("hello")); //true
console.log(isNaN(42)) //false


console.log(isFinite(42)) //true
console.log(isFinite(Infinity)) //false
console.log(isFinite(NaN)) //false
