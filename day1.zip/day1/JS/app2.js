// app2.js

const counter = require('./counter');

console.log(counter.getCount()); // Output: 2 (reflects the state from app1.js)