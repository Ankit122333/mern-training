const db1 = require('./db')
console.log(db1.connection) // simulated connection
