const db2 = require('./db')
console.log(db2.connection) //{}