function findMax(arr){
    return Math.max(...arr)
}

function removeDupli(arr){
    return [...new Set(arr)]
}

module.exports={
    findMax,
    removeDupli
}
