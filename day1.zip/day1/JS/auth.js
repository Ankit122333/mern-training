//simulate user function
function authenticateUser(name2){
    return name2==='admin' // only 'admin' is considered as authenticated.
}
module.exports = {
    authenticateUser
}