// counter.js
let count = 0;

const increment = () => {
    count += 1;
    return count;
};

const getCount = () => {
    return count;
};

module.exports = {
    increment,
    getCount,
};
// Using the Singleton Module