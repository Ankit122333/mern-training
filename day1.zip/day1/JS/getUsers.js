const users = []
function addUser(name1){
    users.push(name1)
}
function getUsers(){
    return users
}
 module.exports = {
    addUser,getUsers
 }