let n=43
let name1="ankit"
let istrue=true
let x
let empty=null

console.log(n)
console.log(name1)
console.log(istrue)
console.log(x)
console.log(empty)

function add(a,b){
    return a+b
}

console.log(add(10,20))

let a=10
let b=-1
let c=9
let d=(++a % --c) - (--b / c++) + (a++ % b--) - ++c;
console.log(d)
let e=a<b && b>c
console.log(e)

let f=b<=d || c>=b
console.log(f)
console.log(c>=b)

let g=(b<=d) != (c>=b)
console.log(g)