// import { add, PI } from "./math.js";
// //import { PI } from "./math.js";
// console.log(PI)  //3.14
// console.log(add(2,8))  //10



//const math1 = require('./math1') //METHOD - 1
// const addition = math1.add(2,4)
// const subtraction = math1.sub(12,4)
// console.log('Addtion is:',addition)
// console.log('subtraction is:', subtraction)


import{add,sub} from "./math1.js"  // METHOD - 2
console.log(add(2,8))
console.log(sub(12,8))