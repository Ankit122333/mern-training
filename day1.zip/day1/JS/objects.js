// const student={
//     name:'Alice',
//     address:{
//         street:'123 Main st',
//         city:'New York',
//     },
//     courses:['Maths','English']
// };
// student.grade = 'A'

// console.log(student.courses[1]);
// console.log(student.address.city);
// console.log(student)
// for.. of => array m use hoga
// for .. in => object m use hota h
// number + string => string
// number - string => number
// null== undefined => true


const book = {
    title: '1984',
    author: 'George',
    year: 1949
};
for(let key in book){ // for.. in ka use hua h yha p 
    console.log(key+':' + book[key]);
}

console.log(Object.keys(book))
console.log(Object.values(book))
console.log(Object.entries(book))

var x=10;
function increment(){
    x++
    return x
}
console.log(increment())


const obj={
    name:"Alice",
    greet: function(){
        console.log(this.name)
    }
}

obj.greet()

const greet = obj.greet;
greet();

// let a 
// a.name = "john"
// console.log(a.name)

// let a = new Object()
// a.name = "john"
// console.log(a.name)
let arr=[1,2,3]
arr[5]=99
console.log(arr)

function outerFunction(outerVariable) {
    return function innerFunction(innerVariable) {
        console.log('Outer Variable: ' + outerVariable);
        console.log('Inner Variable: ' + innerVariable);
    };
}

const closureInstance = outerFunction('Hello');
closureInstance('World');

function greet(name) {
    setTimeout(function() {
        console.log('Hello, ' + name);
    }, 1000);
}

greet('Alice');



function createMultiplier(multiplier) {
    return function(num) {
        return num * multiplier;
    };
}

const double = createMultiplier(2);
const triple = createMultiplier(3);

console.log(double(5));  // Output: 10
console.log(triple(5));  // Output: 15


function Counter() {
    let count = 0;
    return function() {
        count++;
        console.log(count);
    };
}

const counter = Counter();
counter();  // Output: 1
counter();  // Output: 2


// Constructor function
function Person(name, age) {
    this.name = name;
    this.age = age;
}

// Adding a method to the prototype
Person.prototype.greet = function() {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
};

// Creating objects using the constructor
const john = new Person('John', 30);
const jane = new Person('Jane', 25);

// Both john and jane can access the greet method from the prototype
john.greet();  // Output: Hello, my name is John and I am 30 years old.
jane.greet();  // Output: Hello, my name is Jane and I am 25 years old.

console.log(john.__proto__ === Person.prototype)
console.log(john.__proto__.__proto__ === Object.prototype)

function Employee(name, age, jobTitle) {
    Person.call(this, name, age);  // Call Person constructor
    this.jobTitle = jobTitle;
}

// Inherit from Person's prototype
Employee.prototype = Object.create(Person.prototype);

// Add method specific to Employee
Employee.prototype.describeJob = function() {
    console.log(`I am a ${this.jobTitle}.`);
};

// Create an Employee instance
const alice = new Employee('Alice', 28, 'Software Developer');
alice.greet();       // Inherited from Person: "Hello, my name is Alice and I am 28 years old."
alice.describeJob(); // "I am a Software Developer."
