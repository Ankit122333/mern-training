function toUpperCase(str){
    return str.toUpperCase()
}

function contains(mainStr, subStr){
    return mainStr.includes(subStr)
}

module.exports={
    toUpperCase,contains
}