const myModule = require('./lib/myModule')
//const myModule = require()
module.exports = {
    myFunction: myModule.myFunction,
    myAsyncFunction: myModule.myAsyncFunction
}

