const {myFunction,myAsyncFunction} = require('./index')
console.log(myFunction()) //op - Hello from my package!!
//console.log(myAsyncFunction())
myAsyncFunction().then(console.log) // Hello from async function!