function add(a,b){
    return a+b;
}
console.log(add(10,20))
