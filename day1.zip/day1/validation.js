// Select the form and input elements
const form = document.getElementById('myForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

// Error message elements
const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');

// Function to check email validation
function validateEmail() {
    if (emailInput.validity.valueMissing) {
        emailError.textContent = "Email is required.";
    } else if (emailInput.validity.typeMismatch) {
        emailError.textContent = "*Please enter a valid email address.";
    } else {
        emailError.textContent = "";  // No error
    }
}

// Function to check password validation
function validatePassword() {
    if (passwordInput.validity.valueMissing) {
        passwordError.textContent = "Password is required.";
    } else if (passwordInput.validity.tooShort) {
        passwordError.textContent = `*Password should be at least ${passwordInput.minLength} characters long.`;
    } else {
        passwordError.textContent = "";  // No error
    }
}

// Attach validation listeners to input fields
emailInput.addEventListener('input', validateEmail);
passwordInput.addEventListener('input', validatePassword);

// Form submission event handler
form.addEventListener('submit', function(event) {
    validateEmail();
    validatePassword();

    // If either field has an error, prevent form submission
    if (!emailInput.validity.valid || !passwordInput.validity.valid) {
        event.preventDefault();
    }
});
