// document.addEventListener('DOMContentLoaded', function(){
//     const form = document.getElementById('customForm');
//     const usernameInput = document.getElementById('username');
//     const ageInput = document.getElementById('age');
//     const usernameError = document.getElementById('usernameError');
//     const ageError = document.getElementById('ageError');

//     //custom validation for username(name field m sirf letters and numbers hone chahiye)
//     usernameInput.addEventListener('input', function(){
//         const usernameValue = usernameInput.Value
//         if(usernameValue.length<5){
//             usernameInput.setCustomValidity('Username must be of atleast 5 characters long.');
//             usernameError.textContent = `*Username must be of atleast 5 characters long.`;
//         } else if(!/^[a-zA-Z0-9]+$/.test(usernameValue)){
//             usernameInput.setCustomValidity('It should contain only letters and numbers');
//             usernameError.textContent = '*It should contain only letters and numbers';
//         } else {
//             usernameInput.setCustomValidity('');
//             usernameError.textContent = '';
//         }
//     })
//     //custom validation for age(age hamara 18 se 65 k bich ka hona chaiye)
//         ageInput.addEventListener('input', function(){
//         const ageValue = parseInt(ageInput.value, 10);
//         if(ageValue<18 || ageValue>65){
//             ageInput.setCustomValidity('Age must be in between 18 & 65');
//             ageError.textContent = "*Age must be in between 18 & 65";
//         } else {
//             ageInput.setCustomValidity('');
//             usernamageErroreError.textContent = '';
//         }
//     })
//     //form submission handling
//     customForm.addEventListener('submit',function(event){
//         if(!customForm.checkValidity()){
//             event.preventDefault();
//         }

//     })

// })




document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('customForm');
    const usernameInput = document.getElementById('username');
    const ageInput = document.getElementById('age');
    const usernameError = document.getElementById('usernameError');
    const ageError = document.getElementById('ageError');
  
    // Custom validation for Username (e.g., at least 5 characters and no special characters)
    usernameInput.addEventListener('input', function () {
      const usernameValue = usernameInput.value;
      if (usernameValue.length < 5) {
        usernameInput.setCustomValidity('Username must be at least 5 characters long.');
        usernameError.textContent = 'Username must be at least 5 characters long.';
      } else if (!/^[a-zA-Z0-9]+$/.test(usernameValue)) {
        usernameInput.setCustomValidity('Username must contain only letters and numbers.');
        usernameError.textContent = 'Username must contain only letters and numbers.';
      } else {
        usernameInput.setCustomValidity('');
        usernameError.textContent = '';
      }
    });
  
    // Custom validation for Age (e.g., age must be between 18 and 65)
    ageInput.addEventListener('input', function () {
      const ageValue = parseInt(ageInput.value, 10);
      if (ageValue < 18 || ageValue > 65) {
        ageInput.setCustomValidity('Age must be between 18 and 65.');
        ageError.textContent = 'Age must be between 18 and 65.';
      } else {
        ageInput.setCustomValidity('');
        ageError.textContent = '';
      }
    });
  
    // Form submission handling
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
      }
    });
  });
  
